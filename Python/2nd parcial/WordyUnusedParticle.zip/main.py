n1= float(input("ponga su edad"))


rint(" ")
        print("RESULTADO: El producto de",n1,"*",12)
