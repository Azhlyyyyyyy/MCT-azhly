comparador=10

while(comparador==1)
print("hola")
