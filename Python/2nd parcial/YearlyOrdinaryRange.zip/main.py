n1 = float(input("introduce tu edad: ") )


opcion = 0
while True:
    print("""
    Dime, ¿qué quieres hacer?
    3) tu edad en meses  
    print(" ")
      3  print("RESULTADO: El producto de",n1,"*",12,"es igual a",n1*12)
    
          