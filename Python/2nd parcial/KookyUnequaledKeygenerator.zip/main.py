comparador=10

while(comparador<=20):
 Name=input("enter your name:")
  comparador=comparador+1