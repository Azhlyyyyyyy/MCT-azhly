
while True:


  #identacio
  print('holaa')
  print('saludame ')
  
mensaje=input('di algo')

print('reprobados')
 