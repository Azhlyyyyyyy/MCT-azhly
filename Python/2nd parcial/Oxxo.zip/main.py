n1 = float(input("hello what is the price of your item?") )
n2 = float(input("put the other price of the other thing: ") )

opcion = 0
while True:
    print("""
    what do you want?
    
    1) your iva
    
    """)
    opcion = int(input(" n1+n2*.14) )     

    if opcion == 1:
        print(" ")
        print("RESULTADO: La suma de",n1,"+",n2,"es igual a",n1+n2)